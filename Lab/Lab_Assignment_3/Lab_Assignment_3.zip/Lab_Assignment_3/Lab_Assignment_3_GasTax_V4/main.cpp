/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on July 8, 2022, 1:18 PM
 * Purpose: Calculate percentages and dollar amount paid to taxes and the oil company per gallon of gas
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>//Format Library
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const unsigned char DLRS = 100; //Cents to dollars conversion
const unsigned char PERCENT = 100; //Conversion to percent
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned char txGln, //Excise tax/gallon
            stPrc, //Sales Tax Percentage
            txFee; //Cap and trade tax fee
    float ftxGln, //Federal excise tax/gallon
            stAmt, //Amount paid to sales tax
            cGln, //Cost per gallon
            prcPrft, //Oil company profit percent
            totTx, //Total amount of taxes to the government
            totPrft; //Total Profit made by the oil companies
    //Initialize Variables or input
    stPrc = 8;
    txGln=39;
    txFee=10;
    ftxGln=1.84e1f;
    prcPrft=6.5e0f;
    cout<<"Input the amount it costs per gallon of gas in dollars."<<endl;
    cin>>cGln;
    //Map inputs to outputs -> The Process
    totTx=(txGln+txFee+ftxGln)/DLRS;
    //Calculate sales tax amount with other taxes included
    stAmt=cGln-(cGln/((PERCENT+stPrc)/static_cast<float>(PERCENT)));
    totTx+=stAmt;
    //Calculate total profit made by the oil company
    totPrft=(cGln-totTx)-(cGln-totTx)/((PERCENT+prcPrft)/static_cast<float>(PERCENT));
    //Display Results
    cout<<fixed<<setprecision(2);
    cout<<"The total profit made by the oil company per gallon = $"<<totPrft<<endl;
    cout<<"The total amount paid to taxes per gallon           = $"<<totTx<<endl;
    cout<<"The percentage of profit made by the oil company    = "<<totPrft/cGln*PERCENT<<"%"<<endl;
    cout<<"The percentage paid to taxes                        = "<<totTx/cGln*PERCENT<<"%"<<endl; 
    //Exit Stage Right 
    return 0;
}

