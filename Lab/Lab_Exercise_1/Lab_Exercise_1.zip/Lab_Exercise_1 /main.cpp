/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 26, 2022, 4:02 PM
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned char tnkSz, //The size of cars gas tank
            mpg; //Miles per gallon
    float galRq, // Gas required to fill tank 
            s1Prc, //Price for one gallon of gas at station 1 in dollars
            s2Prc, //Price for one gallon of gas at station 2 in dollars
            s1Bcst, //Cost of gas required to fill up tank without mileage added at station 1 in dollars
            s2Bcst, //Cost of gas required to fill up tank without mileage added at station 2 in dollars
            s1Ppg, //Price per gallon at station 1 in dollars
            s2Ppg, //Price per gallon at station 2 in dollars
            s1Dst, //Distance to drive to station 1 in miles
            s2Dst, // Distance to drive to station 2 in miles
            s1Trp, //Total miles to drive to and back from station 1 
            s2Trp, //Total miles to drive to and back from station 2 
            s1Cst, //Final cost to fill up at station 1 including mileage in dollars
            s2Cst, //Final cost to fill up at station 2 including mileage in dollars
            prcFull, //Percent of gas left in tank
            s1Dvcst, //Cost to drive to and from station 1 in dollars
            s2Dvcst; //Cost to drive to and from station 2 in dollars
    //Initialize Variables
    prcFull = 7.5e-1f;
    tnkSz = 22; 
    mpg = 17;
    s1Prc = 4.25e0f;
    s2Prc = 4.09e0f;
    s1Dst = 10;
    s2Dst = 20; 
    //Map inputs to outputs -> The Process
    galRq = tnkSz * (1 - prcFull);
    s1Bcst = galRq * s1Prc;
    s2Bcst = galRq * s2Prc;
    s1Trp = s1Dst * 2;
    s2Trp = s2Dst * 2;
    s1Dvcst = s1Trp/mpg*s1Prc;
    s2Dvcst = s2Trp/mpg*s2Prc;
    s1Cst = s1Bcst + s1Dvcst;
    s2Cst = s2Bcst + s2Dvcst;
    s1Ppg = s1Cst/galRq;
    s2Ppg = s2Cst/galRq;
    //Display Results
    cout << "The cost to fill up at station 1 before mileage is added = $" << s1Bcst << endl
            << "The distance driven in miles back and forth to station 1 = " << s1Trp << endl
            << "The cost of driving to and from station 1 = $" << s1Dvcst << endl
            << "The total cost of station 1 including mileage = $" << s1Cst << endl
            << "The price per gallon at station 1 including mileage = $" << s1Ppg << endl << endl;
    
    cout << "The cost to fill up at station 2 before mileage is added = $" << s2Bcst << endl
            << "The distance driven in miles back and forth to station 2 = " << s2Trp << endl
            << "The cost of driving to and from station 2 = $" << s2Dvcst << endl
            << "The total cost of station 2 including mileage = $" << s2Cst << endl
            << "The price per gallon at station 2 including mileage = $" << s2Ppg << endl;
    
    //Exit Stage Right 
    return 0;
}

