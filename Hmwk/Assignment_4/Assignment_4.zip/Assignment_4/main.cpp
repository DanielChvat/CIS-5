/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 21, 2022, 12:22 PM
 * Purpose: C++ Template to be used in future projects
 */

//System Libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const unsigned char DLRS = 100; //Conversion from cents to dollars
const float GLLN=0.264179; //Conversion from a liter to a gallon
//Function Prototypes
void prblm1();
void prblm2();
void prblm3();
void prblm4();
void prblm5();
void prblm6();
void prblm7();
void prblm8();
void prblm9();
void prblm10();

//Execution Begins Here
int main(int argc, char** argv) {
     //Declare Variables
    char choice;
    
    //Repeat the process
    do{
    
        //Initialize Variables
        cout<<"Which Problem would you like to run"<<endl;
        cout<<"Type 0 for Gaddis_9thEd_Chap5_Prob1_Sum"<<endl;
        cout<<"Type 1 for Gaddis_9thEd_Chap5_Prob7_PayInPennies"<<endl;
        cout<<"Type 2 for Gaddis_9thEd_Chap5_Prob13_MinMax"<<endl;
        cout<<"Type 3 for Gaddis_9thEd_Chap5_Prob22_Rectangle"<<endl;
        cout<<"Type 4 for Gaddis_9thEd_Chap5_Prob23_Pattern"<<endl;
        cout<<"Type 5 for Savitch_9thEd_Chap4_Prob1_MPG"<<endl;
        cout<<"Type 6 for Savitch_9Ed_Chap4_Prob2_FuelEff"<<endl;
        cout<<"Type 7 for Savitch_9Ed_Chap4_Prob4_Inflation"<<endl;
        cout<<"Type 8 for Savitch_9Ed_Chap4_Prob5_EstCost"<<endl;
        cout<<"Type 9 for Savitch_9Ed_Chap4_Prob9_2or3Max"<<endl;
        
        cin>>choice;

        //Map the Inputs to the Outputs
        switch(choice){
            case '0':prblm1();break;
            case '1':prblm2();break;
            case '2':prblm3();break;
            case '3':prblm4();break;
            case '4':prblm5();break;
            case '5':prblm6();break;
            case '6':prblm7();break;
            case '7':prblm8();break;
            case '8':prblm9();break;
            case '9':prblm10();break;
        }
    }while(choice>='0'&&choice<='9');
    
    //Exit Stage Right 
    return 0;
}
void prblm1(){
    //Set the random number seed
    
    //Declare Variables
    unsigned short nLoops, //Number of Loops to be performed
    sum; //Sum of all values up the the number of loops 
    //Initialize or input i.e. set variable values
    nLoops=0;
    sum=0;
    cin>>nLoops;
    //Map inputs -> outputs
    for(int i=0;i<nLoops;i++){
        sum +=i+1;
    }
    //Display the outputs
cout<<"Sum = "<<sum<<endl;
}
void prblm2(){
    //Set the random number seed
    
    //Declare Variables
    unsigned int dlyPmt, //Daily payment
                 totPmt, //Total payment at the end of the days
                 nDays; //Number of days where payment is doubled each days
    //Initialize or input i.e. set variable values
    dlyPmt=1;
    totPmt=dlyPmt;
    cin>>nDays;
    //Map inputs -> outputs
    for(int day=2;day<=nDays;day++){
        dlyPmt*=2;
        totPmt+=dlyPmt;
    }
    //Display the outputs
    cout<<"Pay = $"<<totPmt/100<<"."<<(totPmt%100<10?"0":"\0")<<totPmt%100<<endl;
}
void prblm3(){
     //Set the random number seed
    
    //Declare Variables
    short min, max,num; //Minimum value, Maximum value, Number 
    //Initialize or input i.e. set variable values
    cin>>num;
    min=num;
    max=num;
    //Map inputs -> outputs
        while(num!=-99){
        if(num>max) max=num;
        else if(num<min) min=num;
        cin>>num;
    }
    //Display the outputs
cout<<"Smallest number in the series is "<<min<<endl;
cout<<"Largest  number in the series is "<<max<<endl;
}
void prblm4(){
    //Set the random number seed
    //Declare Variables
    string width, letter; 
    short dmnsins; //Dimensions of the rectangle (width and height)
    //Initialize or input i.e. set variable values
    cin>>dmnsins;
    cin>>letter;
    width=letter;
    //Map inputs -> outputs
    if(dmnsins>0){
    for(int i=0;i<dmnsins-1;i++){
        width+=letter;
    }
    for(int i=0;i<dmnsins-1;i++){
        cout<<width<<endl;
    }
    }
}
void prblm5(){
     //Set the random number seed
    
    //Declare Variables
    short nLoops; //Number of times to loop
    //Initialize or input i.e. set variable values
    cin>>nLoops;
    //Map inputs -> outputs
    for(int rows=1;rows<=nLoops;rows++){
        for(int cols=1;cols<=rows;cols++){
            cout<<"+";
        }
        cout<<endl<<endl;
    }
    for(int rows=1; rows<=nLoops;rows++){
        for(int cols=1;cols<=nLoops+1-rows;cols++){
            cout<<"+";
        }
        if(rows<=nLoops)cout<<endl<<endl;
    }
}
void prblm6(){
     //Set the random number seed
    
    //Declare Variables
    short nLtrs, //Number of Liters consumed
    nMiles; //Number of miles traveled
    char choice; //Choice to do more calculations or stop
    float nGlns, //Number of gallons used
    mpg; //Miles per gallon of the car
    //Initialize or input i.e. set variable values
    //Map inputs -> outputs
    do {
        cout<<"Enter number of liters of gasoline:"<<endl<<endl;
        cin>>nLtrs;
        cout<<"Enter number of miles traveled:"<<endl<<endl;
        cin>>nMiles;
        nGlns = nLtrs*GLLN;
        mpg = nMiles/nGlns;
        cout<<"miles per gallon:"<<endl;
        cout<<fixed<<setprecision(2)<<mpg<<endl;
        cout<<"Again:"<<endl;
        cin>>choice;
        if(choice=='Y'||choice=='y') cout<<endl;
    }while(choice=='Y'||choice=='y');
}
void prblm7(){
    short nLtrs1, nLtrs2, nMls1,nMls2; //Numbers of liters used and miles driven for car 1 and 2
    float mpg1, mpg2; //Miles per gallon for car 1 and 2
    char choice; //Choice to continue doing more calculations or stop
    //Initialize or input i.e. set variable values
    do{
        //Car 1 calculations
        cout<<"Car 1"<<endl;
        cout<<"Enter number of liters of gasoline:"<<endl;
        cin>>nLtrs1;
        cout<<"Enter number of miles traveled:"<<endl;
        cin>>nMls1;
        mpg1 = nMls1/(nLtrs1*GLLN);
        cout<<"miles per gallon: "<<fixed<<setprecision(2)<<mpg1<<endl<<endl;
        //Car 2 calculations
        cout<<"Car 2"<<endl;
        cout<<"Enter number of liters of gasoline:"<<endl;
        cin>>nLtrs2;
        cout<<"Enter number of miles traveled:"<<endl;
        cin>>nMls2;
        mpg2 = nMls2/(nLtrs2*GLLN);
        cout<<"miles per gallon: "<<fixed<<setprecision(2)<<mpg2<<endl<<endl;
        //Determine which car is more fuel efficient
        if(mpg1>mpg2)
        cout<<"Car 1 is more fuel efficient"<<endl<<endl;
        else
        cout<<"Car 2 is more fuel efficient"<<endl<<endl;
        //Determine the users choice
        cout<<"Again:"<<endl;
        cin>>choice;
        if(choice=='Y'||choice=='y')
        cout<<endl;
    }while(choice=='Y'||choice=='y');
}
void prblm8(){
     float oldPrc,//Old Price a year ago
    crntPrc, //Current Price
    infRate; //Inflation Rate in Percent
    char choice; //Choice wheter to do more calculations or stop
    //Initialize or input i.e. set variable values
    do {
        cout<<"Enter current price:"<<endl;
        cin>>crntPrc;
        cout<<"Enter year-ago price:"<<endl;
        cin>>oldPrc;
        infRate=(crntPrc-oldPrc)/oldPrc*100;
        cout<<"Inflation rate: "<<fixed<<setprecision(2)<<infRate<<"%"<<endl<<endl;
        cout<<"Again:"<<endl;
        cin>>choice;
        if(choice=='Y'||choice=='y') cout<<endl;
    }while(choice=='Y'||choice=='y');
}
void prblm9(){
       //Set the random number seed
    
    //Declare Variables
    float oldPrc,//Old Price a year ago
    crntPrc, //Current Price
    infRate, //Inflation Rate in Percent
    yr1Prc, //Estimated price after 1 year
    yr2Prc; //Estimated price after 2 years
    char choice; //Choice wheter to do more calculations or stop
    //Initialize or input i.e. set variable values
    do {
        cout<<"Enter current price:"<<endl;
        cin>>crntPrc;
        cout<<"Enter year-ago price:"<<endl;
        cin>>oldPrc;
        infRate=(crntPrc-oldPrc)/oldPrc*100;
        cout<<"Inflation rate: "<<fixed<<setprecision(2)<<infRate<<"%"<<endl<<endl;
        yr1Prc=crntPrc*infRate/100+crntPrc;
        cout<<"Price in one year: $"<<fixed<<setprecision(2)<<yr1Prc<<endl;
        yr2Prc=yr1Prc*infRate/100+yr1Prc;
        cout<<"Price in two year: $"<<fixed<<setprecision(2)<<yr2Prc<<endl<<endl;
        cout<<"Again:"<<endl;
        cin>>choice;
        if(choice=='Y'||choice=='y') cout<<endl;
    }while(choice=='Y'||choice=='y');
}
void prblm10(){
      //Set the random number seed
    
    //Declare Variables
    float numbers[3], max2, max3; 
    //Initialize or input i.e. set variable values
    cout<<"Enter first number:"<<endl<<endl;
    cin>>numbers[0];
    cout<<"Enter Second number:"<<endl<<endl;
    cin>>numbers[1];
    cout<<"Enter third number:"<<endl<<endl;
    cin>>numbers[2];
    
    max2=numbers[1];
    max3=numbers[2];
    //Map inputs -> outputs
    for (int a=0;a<1;a++){
        if(numbers[a]>max2){
            max2=numbers[a];
        }
    }
    for (int b=0;b<2;b++){
        if(numbers[b]>max3){
            max3=numbers[b];
        }
    }
    //Display the outputs
    cout<<"Largest number from two parameter function:"<<endl<<max2<<endl<<endl;
    cout<<"Largest number from three parameter function:"<<endl<<max3<<endl;
}
