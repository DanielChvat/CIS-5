/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 6:05 PM
 * Purpose: Find the sum of two numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    short val1, //First value
            val2, //Second value
            sum; //Sum of first and second values 
    
    //Initialize Variables
    val1 = 50;
    val2 = 100;
    //Map inputs to outputs -> The Process
    sum = val1 + val2;
    //Display Results
    cout << val1 << " + " << val2 << " = " << sum << endl;
    //Exit Stage Right 
    return 0;
}

