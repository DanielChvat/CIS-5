/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 6:29 PM
 * Purpose: Calculate how much the ocean level will raise after a certain amount of years
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    float lvlInc, //How much ocean raises each year in millimeters
            lvl5, //Level increase after 5 years
            lvl7, //Level increase after 7 years
            lvl10; //Level increase after 10 years
            
    //Initialize Variables
    lvlInc = 1.5e0f;
    //Map inputs to outputs -> The Process
    lvl5 = lvlInc * 5;
    lvl7 = lvlInc * 7; 
    lvl10 = lvlInc * 10;
    //Display Results
    cout <<" The ocean will have raised " << lvl5 << " millimeters" << "after 5 years" << endl;
    cout <<" The ocean will have raised " << lvl7 << " millimeters" << "after 7 years" << endl;
    cout <<" The ocean will have raised " << lvl10 << " millimeters" << "after 10 years" << endl;
    //Exit Stage Right 
    return 0;
}

