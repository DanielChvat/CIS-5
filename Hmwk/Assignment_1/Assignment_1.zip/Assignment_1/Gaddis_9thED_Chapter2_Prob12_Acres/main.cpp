/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 6:41 PM
 * Purpose: Convert square feet into acres
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float ara, //Total area of land in ft^2
            acrs; //Number of acres
    //Initialize Variables
    ara = 391876;
    //Map inputs to outputs -> The Process
            acrs = ara / 43560.0;
    //Display Results
            cout << "The number of acres in " << ara << " square feet is " << acrs << " acres" << endl;
    //Exit Stage Right 
    return 0;
}

