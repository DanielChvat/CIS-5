/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 6:11 PM
 * Purpose: Calculate the amount made by the East Coast Division
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const unsigned char PERCENT = 100; 
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float totSls, //Total amount of sales
            estSls; //Sales made by East Coast Division
    unsigned char estPrc; //Percent of sales made by East Coast Division
    //Initialize Variables
    totSls = 8.6e0f;
    estPrc = 58;
    //Map inputs to outputs -> The Process
    estSls = totSls * estPrc / PERCENT;
    //Display Results
    cout << "The East Coast Division made " << estSls << " million dollars" << endl; 
    //Exit Stage Right 
    return 0;
}

