/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 6:19 PM
 * Purpose: Calculate the average of 5 numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    short val1, val2, val3, val4, val5; //All of the values that will be averaged
    short sum; //The sum of all the values added together
    float avg; //The average of all the values
    //Initialize Variables
    val1 = 28;
    val2 = 32;
    val3 = 37;
    val4 = 24;
    val5 = 33;
    //Map inputs to outputs -> The Process
    sum = val1 + val2 + val3 + val4+ val5;
    avg = sum / 5.0;
    //Display Results
    cout << "The average of " << val1 << "," << val2 << "," << val3 << "," << val4 << "," << val5 << " = " 
            << avg << endl; 
    //Exit Stage Right 
    return 0;
}

