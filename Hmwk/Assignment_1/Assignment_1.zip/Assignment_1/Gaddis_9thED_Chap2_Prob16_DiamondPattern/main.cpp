/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 5:25 PM
 * Purpose: Create a diamond pattern
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map inputs to outputs -> The Process
    
    //Display Results
    cout <<"   *   " << endl;
    cout <<"  ***  " << endl;
    cout <<" ***** " << endl;
    cout <<"*******" << endl;
    cout <<" ***** " << endl;
    cout <<"  ***  " << endl;
    cout <<"   *   " << endl;
    //Exit Stage Right 
    return 0;
}

