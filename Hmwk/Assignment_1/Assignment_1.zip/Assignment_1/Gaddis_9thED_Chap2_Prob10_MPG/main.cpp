/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 4:57 PM
 * Purpose: Find the mpg of a car
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned short mlsDrvn; //Number of Miles Driven
    unsigned char mpg,//Miles Per Gallon
            nGalns; //Number of Gallons 
    //Initialize Variables
    mlsDrvn = 375; 
    nGalns = 15; 
    //Map inputs to outputs -> The Process
    mpg = mlsDrvn / nGalns; 
    //Display Results
    cout << static_cast<int>(mpg) << " Miles Per Gallon = " << mlsDrvn << " Miles Driven / " << static_cast<int>(nGalns) << " Gallons Used";
    //Exit Stage Right 
    return 0;
}

