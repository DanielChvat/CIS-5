/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 5:30 PM
 * Purpose: Calculate the total price of shares with commission
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const unsigned char PERCENT = 100;
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    unsigned short nShrs; //Number of shares being bought
    float prc, //Price for one share
            bPrc, //Base price of the shares before having to pay commission to stockbroker
            comAmt, //Amount being paid for the commission
            totAmt; //Total amount being paid
    unsigned char pctCom; //Percent commission being paid to stockbroker
    
    //Initialize Variables
    nShrs = 750;
    prc = 3.5e1f;
    pctCom = 2; 
    //Map inputs to outputs -> The Process
    bPrc = nShrs * prc;
    comAmt = bPrc * pctCom / PERCENT;
    totAmt = bPrc + comAmt;
    //Display Results
    cout << "The price of the shares before commission is $" << bPrc << endl
            << "The Commission amount is $" << comAmt << endl
            << "The total price including commission is $" << totAmt << endl;
    //Exit Stage Right 
    return 0;
}

