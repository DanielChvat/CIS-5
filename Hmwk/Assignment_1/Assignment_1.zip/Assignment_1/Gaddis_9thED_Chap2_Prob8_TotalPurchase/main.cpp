/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 7:40 PM
 * Purpose: Calculate the total price of 5 items with sales tax
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const unsigned char PERCENT = 100;
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float itm1, //Price of item 1 
            itm2, //Price of item 2 
            itm3, //Price of item 3 
            itm4, //Price of item 4 
            itm5, //Price of item 5
            sum, //Sum of the prices of all 5 items before tax
            stAmt, //Amount of sales tax
            ttl; //Total price of all the items and tax
    unsigned char slsTx = 7;
    //Initialize Variables
    itm1 = 1.595e1f;
    itm2 = 2.495e1f;
    itm3 = 6.95e0f; 
    itm4 = 1.295e1f;
    itm5 = 3.95e0f;
    //Map inputs to outputs -> The Process
    sum = itm1+itm2+itm3+itm4+itm5;
    stAmt = sum * slsTx / PERCENT;
    ttl = sum + stAmt;
    //Display Results
    cout << "The price of item 1 is $" << itm1 << endl
            << "The price of item 2 is $" << itm2 << endl
            << "The price of item 3 is $" << itm3 << endl
            << "The price of item 4 is $" << itm4 << endl
            << "The price of item 5 is $" << itm5 << endl
            << "The subtotal of the sale is $" << sum << endl
            << "The amount of sales tax is $" << stAmt << endl
            << "The total price is $" << ttl << endl;
    //Exit Stage Right 
    return 0;
}

