/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on June 24, 2022, 5:52 PM
 * Purpose: Calculate the number of gallons of paint required to paint a fence
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float pCvg, //Coverage of a gallon of paint in ft^2
            fncLen, //Length of the fence in ft
            fncHgt, //Height of the fence in ft
            srfAra, //Surface area of 1 side of the fence
            srfCov; //Coverage of both sides two times
    int nGalns; //Number of Gallons required to paint the fence
    //Initialize Variables
    pCvg = 3.4e2f;
    fncLen = 1.0e2f;
    fncHgt = 6.0e0f;
    //Map inputs to outputs -> The Process
    srfAra = fncLen * fncHgt;
    srfCov = 2*2*srfAra;
    nGalns = srfCov / pCvg + 1;
    //Display Results
    cout << "The number of gallons of paint required = " << nGalns << endl;
    //Exit Stage Right 
    return 0;
}

