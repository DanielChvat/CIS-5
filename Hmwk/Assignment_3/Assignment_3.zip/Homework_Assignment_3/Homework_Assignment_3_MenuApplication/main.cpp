/* 
 * File:   main.cpp
 * Author: Daniel Chvat
 *
 * Created on July 10, 2022, 12:01 PM
 * Purpose: Application for all Homework Assignment 3 Problems
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip> //Format Library
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed once here
    
    //Declare variables here
    int choose;//Choose a problem
    
    //Initialize variables here
    do{
        //List of Problems which can be run by the program
        cout<<"Choose from the following Menu Items"<<endl;
        cout<<"Problem 0 - Gaddis_9thEd_Chap4_Prob8_SortNames"<<endl;
        cout<<"Problem 1 - Gaddis_9thEd_Chap4_Prob11_Books"<<endl;
        cout<<"Problem 2 - Gaddis_9thEd_Chap4_Prob12_BankCharges"<<endl;
        cout<<"Problem 3 - Gaddis_9thEd_Chap4_Prob14_Race"<<endl;
        cout<<"Problem 4 - Gaddis_9thEd_Chap4_Prob23_ISP"<<endl;
        cout<<"Problem 5 - Savitch_9thEd_Chap3_PracProb1_RockPaperScissors"<<endl;
        cout<<"Problem 6 - Savitch_9thEd_Chap3_Prob3_Roman_Conversion"<<endl;
        cout<<"Problem 7 - Savitch_9thEd_Chap3_PracProb4_CompatibleSigns"<<endl;
        cout<<"10 or greater, all negatives to exit"<<endl;
        cin>>choose;
        
        switch(choose){
            case 0:{
    //Set the random number seed
    
    //Declare Variables
    string nm1,nm2,nm3,first,second,third;
    unsigned char a,b,c;
    //Initialize or input i.e. set variable values
    cout<<"Sorting Names"<<endl;
    cout<<"Input 3 names"<<endl;
    cin>>nm1>>nm2>>nm3;
    //Map inputs -> outputs
    if (nm1<nm2 && nm1<nm3)first=nm1;
    else if (nm1>nm2 && nm1<nm3)second=nm1;
    else if (nm1<nm2 && nm1>nm3)second=nm1;
    else if (nm1>nm2 && nm1>nm3)third=nm1;
    
    if (nm2<nm1 && nm2<nm3)first=nm2;
    else if (nm2>nm1 && nm2<nm3)second=nm2;
    else if (nm2<nm1 && nm2>nm3)second=nm2;
    else if (nm2>nm1 && nm2>nm3)third=nm2;
    
    if (nm3<nm1 && nm3<nm2)first=nm3;
    else if (nm3>nm1 && nm3<nm2)second=nm3;
    else if (nm3<nm1 && nm3>nm2)second=nm3;
    else if (nm3>nm1 && nm3>nm2)third=nm3;
    
    //Display the outputs
    cout<<first<<endl;
    cout<<second<<endl;
    cout<<third<<endl;
    break;}
            case 1:{
    //Set the random number seed
    
    //Declare Variables
    short nBooks, nPoints; //Number of books purchased and points received for the month
    //Initialize or input i.e. set variable values
    cout<<"Book Worm Points"<<endl;
    cout<<"Input the number of books purchased this month."<<endl;
    cin>>nBooks; 
    //Map inputs -> outputs
    nPoints = nBooks==0?0:nBooks==1?5:nBooks==3?30:nBooks>=4?60:0;
    //Display the outputs
    cout<<"Books purchased ="<<setw(3)<<nBooks<<endl;
    cout<<"Points earned   ="<<setw(3)<<nPoints<<endl;
                break;}
            case 2:{
    //Set the random number seed
    
    //Declare Variables
    short nChcks; //Number of checks written 
    float fee, tFee,cBal, nBal; //Fee being charged per check, total of all the fees, current balance of the bank account,and the new balance of the bank account. 
    char mFee, lBalfee; //Montly Fee and Low Balance Fee
    //Initialize or input i.e. set variable values
    cout<<"Monthly Bank Fees"<<endl;
    cout<<"Input Current Bank Balance and Number of Checks"<<endl;
    cin>>cBal>>nChcks;
    if(cBal<0){
        cout<<"The account is overdrawn.";
        return 0;
    }
    else if (nChcks<0){
        cout<<"Number of Checks Must be Positive";
        return 0;
    }
    mFee=10;
    //Map inputs -> outputs
    fee=nChcks<20?1e-1f:nChcks>=20 && nChcks<=39?8e-2f:nChcks>=40 && nChcks<=59?6e-2f:nChcks>=60?4e-2f:0;
    lBalfee=cBal<400?15:0;
    tFee = nChcks*fee;
    nBal = cBal-lBalfee-tFee-mFee;
    //Display the outputs
    cout<<"Balance     $"<<fixed<<setprecision(2)<<setw(9)<<cBal<<endl;
    cout<<"Check Fee   $"<<fixed<<setprecision(2)<<setw(9)<<tFee<<endl;
    cout<<"Monthly Fee $"<<fixed<<setprecision(2)<<setw(9)<<static_cast<float>(mFee)<<endl;
    cout<<"Low Balance $"<<fixed<<setprecision(2)<<setw(9)<<static_cast<float>(lBalfee)<<endl;
    cout<<"New Balance $"<<fixed<<setprecision(2)<<setw(9)<<nBal<<endl;
                break;}
            case 3:{
    //Set the random number seed
    
    //Declare Variables
    string nm1,nm2,nm3; //Names of the three people
    short tm1,tm2,tm3; //Times of the three people
    //Initialize or input i.e. set variable values
    cout<<"Race Ranking Program"<<endl;
    cout<<"Input 3 Runners"<<endl;
    cout<<"Their names, then their times"<<endl;
      cin>>nm1>>tm1>>nm2>>tm2>>nm3>>tm3;
    //Map inputs -> outputs
    if(tm1<0 || tm2<0 ||tm3<0)return 0;
    //Display the outputs
    if(tm1<tm2 && tm1<tm3){
        cout<<nm1<<"\t"<<setw(3)<<tm1<<endl;;
        if(tm2<tm3){
        cout<<nm2<<"\t"<<setw(3)<<tm2<<endl;
        cout<<nm3<<"\t"<<setw(3)<<tm3<<endl;
        }else{
        cout<<nm3<<"\t"<<setw(3)<<tm3<<endl;
        cout<<nm2<<"\t"<<setw(3)<<tm2<<endl;
        }
    }
    if(tm2<tm1 && tm2<tm3){
        cout<<nm2<<"\t"<<setw(3)<<tm2<<endl;
        if(tm1<tm3){
        cout<<nm1<<"\t"<<setw(3)<<tm1<<endl;
        cout<<nm3<<"\t"<<setw(3)<<tm3<<endl;
        }else{
        cout<<nm3<<"\t"<<setw(3)<<tm3<<endl;
        cout<<nm1<<"\t"<<setw(3)<<tm1<<endl;
        }
    }
    if(tm3<tm1 && tm3<tm2){
        cout<<nm3<<"\t"<<setw(3)<<tm3<<endl;
        if(tm2<tm1){
        cout<<nm2<<"\t"<<setw(3)<<tm2<<endl;
        cout<<nm1<<"\t"<<setw(3)<<tm1<<endl;
        }else{
        cout<<nm1<<"\t"<<setw(3)<<tm1<<endl;
        cout<<nm2<<"\t"<<setw(3)<<tm2<<endl;
        }
    }
                break;}
            case 4:{
    //Set the random number seed
    
    //Declare Variables
    string pkg; //The package the customer is using
    short nHrs, xtraHrs; //The number of hours used and the number of additional hours used
    float bill; //The final bill for the month
    //Initialize or input i.e. set variable values
    cout<<"ISP Bill"<<endl;
    cout<<"Input Package and Hours"<<endl;
    xtraHrs=0;
    nHrs=0;
    bill=0;
    cin>>pkg>>nHrs;
    //Map inputs -> outputs
    if(nHrs>744)return 0;
    if(pkg=="A"){
        xtraHrs=nHrs>10?nHrs-10:0;
        bill=9.95+xtraHrs*2;
    }else if(pkg=="B"){
        xtraHrs=nHrs>20?nHrs-20:0;
        bill=14.95+xtraHrs;
    }else if(pkg=="C"){
        bill=19.95;
    }else return 0;
    //Display the outputs
    cout<<"Bill = $ "<<bill<<endl;
                break;}
            case 5:{
    //Set the random number seed
    
    //Declare Variables
    char p1, p2; //Input for player 1 and player 2 
    //Initialize or input i.e. set variable values
    cout<<"Rock Paper Scissors Game"<<endl;
    cout<<"Input Player 1 and Player 2 Choices"<<endl;
    cin>>p1>>p2;
    //Map inputs -> outputs
    if(p1==p2){
        cout<<"Nobody wins."<<endl;
    }else if(p1=='P'||p1=='p'){
        if(p2=='R'||p2=='r')cout<<"Paper covers rock."<<endl;
        else if(p2=='S'||p2=='s')cout<<"Scissors cuts paper."<<endl;
    }else if(p1=='R'||p1=='r'){
        if(p2=='P'||p2=='p')cout<<"Paper covers rock."<<endl;
        else if(p2=='S'||p2=='s')cout<<"Rock breaks scissors."<<endl;
    }else if(p1=='S'||p1=='s'){
        if(p2=='P'||p2=='p')cout<<"Scissors cuts paper."<<endl;
        else if(p2=='R'||p2=='r')cout<<"Rock breaks scissors."<<endl;
    }else cout<<"Nobody wins."<<endl;
                break;}
            case 6:{
    //Set the random number seed
    
    //Declare Variables
    short number; //Number to convert to roman numerals
    string roman; //Number converted to roman numerals
    char n1000s,n100s,n10s,n1s; //Number 1000s, 100s, 10s, and 1s
    //Initialize or input i.e. set variable values
    cout<<"Arabic to Roman numeral conversion."<<endl;
    cout<<"Input the integer to convert."<<endl;
    cin>>number;
    //Map inputs -> outputs
    if(number<1000||number>3000){
        cout<<number<<" is Out of Range!";
        return 0;
    }
    n1000s=number/1000;
    n100s=number%1000/100;
    n10s=number%100/10;
    n1s=number%10;
    
    switch(n1000s){
        case 3:roman+="M";
        case 2:roman+="M";
        case 1:roman+="M";
    }
    switch(n100s){
        case 9:roman+="CM";break;
        case 8:roman+="DCCC";break;
        case 7:roman+="DCC";break;
        case 6:roman+="DC";break;
        case 5:roman+="D";break;
        case 4:roman+="CD";break;
        case 3:roman+="CCC";break;
        case 2:roman+="CC";break;
        case 1:roman+="C";break;
    }
    switch(n10s){
        case 9:roman+="XC";break;
        case 8:roman+="LXXX";break;
        case 7:roman+="LXX";break;
        case 6:roman+="LX";break;
        case 5:roman+="L";break;
        case 4:roman+="XL";break;
        case 3:roman+="XXX";break;
        case 2:roman+="XX";break;
        case 1:roman+="X";break;
    }
    switch(n1s){
        case 9:roman+="IX";break;
        case 8:roman+="VIII";break;
        case 7:roman+="VII";break;
        case 6:roman+="VI";break;
        case 5:roman+="V";break;
        case 4:roman+="IV";break;
        case 3:roman+="III";break;
        case 2:roman+="II";break;
        case 1:roman+="I";break;
    }
    //Display the outputs
    cout<<number<<" is equal to "<<roman<<endl;
                break;}
            case 7:{
    //Set the random number seed
    
    //Declare Variables
    string s1,s2,e1,e2;
    //Initialize or input i.e. set variable values
    cout<<"Horoscope Program which examines compatible signs."<<endl;
    cout<<"Input 2 signs."<<endl;
    cin>>s1>>s2;
    //Map inputs -> outputs
    if(s1=="Aries"||s1=="Leo"||s1=="Sagittarius")e1="Fire";
    else if(s1=="Taurus"||s1=="Virgo"||s1=="Capricorn")e1="Earth";
    else if(s1=="Gemini"||s1=="Libra"||s1=="Aqyaruys")e1="Wind";
    else if(s1=="Cancer"||s1=="Scorpio"||s1=="Pisces")e1="Water";
    
    if(s1=="Aries"||s1=="Leo"||s1=="Sagittarius")e2="Fire";
    else if(s2=="Taurus"||s2=="Virgo"||s2=="Capricorn")e2="Earth";
    else if(s2=="Gemini"||s2=="Libra"||s2=="Aqyaruys")e2="Wind";
    else if(s2=="Cancer"||s2=="Scorpio"||s2=="Pisces")e2="Water";
    //Display the outputs
    if(e1==e2)cout<<s1<<" and "<<s2<< " are compatible "<<e1<<" signs."<<endl;
    else cout<<s1<<" and "<<s2<<" are not compatible signs."<<endl;
                break;}
            default:cout<<"Exiting the Menu"<<endl;
        }
    }while(choose>=0 && choose<=9);

    return 0;
}