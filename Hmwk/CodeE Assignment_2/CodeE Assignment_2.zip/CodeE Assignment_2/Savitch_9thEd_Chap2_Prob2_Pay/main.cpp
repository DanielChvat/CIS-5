/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip> //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    short salary; //Pervious annual salary
    float mSalary, //New monthly salary
     rtroPay, //Retroactive pay
     nSalary, //New annual salary
     prcInc; //Percent retroactive salary increase
    //Initialize or input i.e. set variable values
    cout<<"Input previous annual salary."<<endl;
    cin>>salary;
    prcInc = 7.6e-2f;
    //Map inputs -> outputs
    rtroPay = (salary/2)*prcInc;
    nSalary = salary+2*rtroPay;
    mSalary=nSalary/12;
    //Display the outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Retroactive pay    = $ "<<setw(6)<<rtroPay<<endl;
    cout<<"New annual salary  = $"<<setw(6)<<nSalary<<endl;
    cout<<"New monthly salary = $ "<<setw(6)<<mSalary;
    
    //Exit stage right or left!
    return 0;
}