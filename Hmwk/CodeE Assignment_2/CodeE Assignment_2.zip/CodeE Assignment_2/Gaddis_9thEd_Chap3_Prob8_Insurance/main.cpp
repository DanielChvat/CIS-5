/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const unsigned char PERCENT = 100;
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float rpCst, //Cost to replace the building
    insPerc, //Percent advised to insure buildings
    minIns; //Minimum insurance customer must pay for the building
    //Initialize or input i.e. set variable values
    cout <<"Insurance Calculator"<<endl
    <<"How much is your house worth?"<<endl;
    cin >> rpCst;
    insPerc = 80;
    //Map inputs -> outputs
    minIns = rpCst * insPerc/PERCENT;
    //Display the outputs
cout<<"You need $"<<minIns<<" of insurance.";
    //Exit stage right or left!
    return 0;
}