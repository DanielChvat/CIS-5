/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    unsigned char nBag, //Number of cookies in a bag
    npSrvng, //Number of cookies in one serving
    nSrvngs; //Number of servings in a bag
    short clries; //Number of calories in one serving of cookies
    float nAte, //Number of cookies ate
    svgsAte, //Number of servings eaten
    calAte; //Number of calories consumed
    //Initialize or input i.e. set variable values
    cout<<"Calorie Counter" <<endl;
    cout<<"How many cookies did you eat?"<<endl;
    cin>>nAte;
    nBag = 40;
    nSrvngs = 10;
    clries = 300;
    //Map inputs -> outputs
    npSrvng = nBag/nSrvngs;
    svgsAte = nAte/npSrvng;
    calAte = svgsAte * clries;
    //Display the outputs
    cout<<"You consumed "<<calAte<<" calories."; 
    //Exit stage right or left!
    return 0;
}