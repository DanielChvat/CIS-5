/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float ASPERC = 1e-3f;
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    unsigned short nCans, //Number of cans that can be consumed before death
    weight; //Desired weight of the person
    float ratio, //Ratio of artificial sweetener needed to kill to a mouse
    gWeight; //Desired weight of the person in grams
    
    //Initialize or input i.e. set variable values
    cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
    cout<<"Input the desired dieters weight in lbs."<<endl;
    cin>>weight;
    ratio = 5/35.0;
    //Map inputs -> outputs
    gWeight=(45359.2/100)*weight;
    nCans = (gWeight*ratio)/(350*ASPERC);
    //Display the outputs
cout<<"The maximum number of soda pop cans"<<endl;
cout<<"which can be consumed is "<<nCans<<" cans";
    //Exit stage right or left!
    return 0;
}