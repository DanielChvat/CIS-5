/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cmath> //Math Library
#include <iomanip> //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float dAngle, //Angle in degrees
    rAngle, //Angle in radians
    sAngle, //Sin of the angle
    csAngle, //Cosine of the angle
    tnAngle; //Tangent of the angle
    //Initialize or input i.e. set variable values
    cout<<"Calculate trig functions"<<endl;
    cout<<"Input the angle in degrees."<<endl;
    cin>>dAngle;
    //Map inputs -> outputs
    rAngle = dAngle*M_PI/180;
    sAngle = sin(rAngle);
    csAngle = cos(rAngle);
    tnAngle = tan(rAngle);
    //Display the outputs
    cout<<noshowpoint<<"sin("<<dAngle<<") = "<<fixed<<setprecision(4)<<showpoint<<sAngle<<endl;
    cout<<fixed<<setprecision(0)<<noshowpoint<<"cos("<<dAngle<<") = "<<fixed<<setprecision(4)<<showpoint<<csAngle<<endl;
    cout<<fixed<<setprecision(0)<<noshowpoint<<"tan("<<dAngle<<") = "<<fixed<<setprecision(4)<<showpoint<<tnAngle;
    //Exit stage right or left!
    return 0;
}