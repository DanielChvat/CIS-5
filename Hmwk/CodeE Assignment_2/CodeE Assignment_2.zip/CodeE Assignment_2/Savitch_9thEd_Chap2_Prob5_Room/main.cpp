/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    short cap, //Maximum number of people allowed in the room 
    nPpl, //Number of people attending the meeting
    nExc; //Number of people the mustbe exculded to meet with fire regulations
    //Initialize or input i.e. set variable values
    cout<<"Input the maximum room capacity and the number of people"<<endl;
    cin>>cap>>nPpl;
    //Map inputs -> outputs
    nExc =nPpl>cap?nPpl-cap:0;
    //Display the outputs
if (nExc >0) {
    cout<<"Meeting cannot be held."<<endl;
    cout<<"Reduce number of people by "<<nExc<<" to avoid fire violation.";
}
else {
cout<<"Meeting can be held."<<endl;
    cout<<"Increase number of people by "<<cap-nPpl<<" will be allowed without violation.";
}

    //Exit stage right or left!
    return 0;
}